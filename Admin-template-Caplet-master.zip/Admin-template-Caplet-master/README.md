# Admin-template-Caplet
Caplet Admin is modern flat admin template , based on Bootstrap Framework 3+HTML5+CSS3 more plugin includes for all purpose use.
